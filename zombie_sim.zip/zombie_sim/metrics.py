"""Métriques d'évaluation : clusters (convois), polarisation, encerclement."""
import numpy as np
from scipy import ndimage

_STRUCT = np.ones((3, 3), dtype=bool)


def cluster_sizes(civ_positions, size, link=2):
    """Taille des groupes de civils (deux civils sont liés si distance de Chebyshev <= link)."""
    if len(civ_positions) == 0:
        return []
    mask = np.zeros((size, size), dtype=bool)
    for r, c in civ_positions:
        mask[r, c] = True
    dil = ndimage.binary_dilation(mask, structure=_STRUCT, iterations=max(1, link - 1))
    lab, n = ndimage.label(dil, structure=_STRUCT)
    counts = np.bincount(lab[mask], minlength=n + 1)[1:]
    return counts[counts > 0].tolist()


def polarization(H, M):
    """Alignement local des cap des civils en mouvement (1 = convoi parfaitement aligné).
    H : (n,2) caps unitaires (0 si immobile) ; M : (n,n) voisinage booléen."""
    n = len(H)
    if n == 0:
        return np.nan
    Mi = (M | np.eye(n, dtype=bool)).astype(float)
    moved = (np.abs(H).sum(1) > 0).astype(float)
    cnt = Mi @ moved
    S = Mi @ H
    ok = (cnt >= 3) & (moved > 0)
    if not ok.any():
        return np.nan
    return float(np.mean(np.linalg.norm(S[ok], axis=1) / cnt[ok]))


def encirclement(civ_positions, zomb_positions, radius=3, min_z=3):
    """Indice d'encerclement : pour chaque civil entouré d'au moins `min_z` zombies dans
    `radius`, fraction des 8 secteurs angulaires occupés par au moins un zombie.
    1.0 = encerclement complet. Renvoie (moyenne, nb de civils concernés)."""
    if len(civ_positions) == 0 or len(zomb_positions) < min_z:
        return np.nan, 0
    Z = np.asarray(zomb_positions)
    vals = []
    for c in civ_positions:
        d = Z - np.asarray(c)
        cheb = np.abs(d).max(1)
        sel = (cheb <= radius) & (cheb > 0)
        if sel.sum() >= min_z:
            ang = np.arctan2(d[sel, 0], d[sel, 1])
            sector = (((ang + np.pi) / (2 * np.pi)) * 8).astype(int) % 8
            vals.append(len(set(sector.tolist())) / 8.0)
    if not vals:
        return np.nan, 0
    return float(np.mean(vals)), len(vals)
