# Lancement du projet sous Windows (PowerShell).
# Usage :  .\lancer.ps1 test      -> une simulation + test rapide (quelques minutes)
#          .\lancer.ps1 gif       -> génère simulation.gif
#          .\lancer.ps1 complet   -> campagne complète (30 répétitions, 15-25 min)
param([string]$mode = "test")

# Choix automatique du Python : 3.11, 3.12, 3.13 puis python par défaut
$py = $null
foreach ($v in @("3.12", "3.13", "3.11")) {
    & py "-$v" --version 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $py = @("py", "-$v"); break }
}
if (-not $py) { $py = @("python") }
Write-Host "Python utilisé :" ($py -join " ")

& $py[0] $py[1..($py.Length-1)] -m pip install -r requirements.txt

switch ($mode) {
    "test"    { & $py[0] $py[1..($py.Length-1)] model.py
                & $py[0] $py[1..($py.Length-1)] run_experiments.py --reps 3 --quick --out results_test }
    "gif"     { & $py[0] $py[1..($py.Length-1)] viz.py --seed 3 --out simulation.gif }
    "complet" { & $py[0] $py[1..($py.Length-1)] run_experiments.py --reps 30 --out results }
    default   { Write-Host "Mode inconnu : test | gif | complet" }
}
