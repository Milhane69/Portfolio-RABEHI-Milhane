# Survie lors d'une apocalypse zombie urbaine — simulation multi-agents

Projet « IA et Systèmes Complexes » 2026/2027. Moteur en **Python pur** (numpy, scipy, pandas, matplotlib) :
il ne dépend pas de Mesa.

## Documentation complète

`Documentation_Projet_Zombie.docx` (Word, 14 pages) : scénario, littérature, modèle, code, lancement, expériences, résultats, limites, plan de présentation, dépannage.

## Fichiers

| Fichier | Rôle |
|---|---|
| `model.py` | Le modèle : ville, agents (civils, zombies, soldats), bruit, barricades, spores, métriques |
| `metrics.py` | Indices d'émergence : taille des groupes, polarisation (convois), encerclement |
| `run_experiments.py` | Campagne : E1 courbes, E2 scénarios, E3 ablations (émergence), E4 sensibilité + seuil critique |
| `viz.py` | GIF de la simulation, ou fenêtre en direct (`--live`) |
| `lancer.ps1` | Lancement automatique sous Windows |
| `results/` | Résultats de la campagne (30 répétitions) : figures `fig1..4` et tableaux CSV |
| `simulation.gif` | Exemple de simulation |

## Lancer (Windows / PowerShell)

Dans un **nouveau dossier** (pas dans un ancien projet Mesa), ouvre PowerShell dans `zombie_sim` :

```powershell
py -3.11 -m pip install -r requirements.txt
py -3.11 model.py                                  # 1 simulation, ~1 s
py -3.11 viz.py --seed 3 --out simulation.gif      # GIF
py -3.11 run_experiments.py --reps 3 --quick       # test rapide de la campagne
py -3.11 run_experiments.py --reps 30              # campagne complète (15-30 min)
```

Ou en une commande : `.\lancer.ps1 test`, `.\lancer.ps1 gif`, `.\lancer.ps1 complet`
(si PowerShell refuse : `Set-ExecutionPolicy -Scope Process Bypass`).

Mac/Linux : remplacer `py -3.11` par `python3`.

Options de `run_experiments.py` : `--reps N`, `--quick`, `--workers K`, `--only e1,e2,e3,e4`, `--out dossier`.
Résultats : `results/fig1..4_*.png` et tableaux `.csv`.

## Le modèle en bref

- **Environnement** : grille 43×43, rues de 2 cases et immeubles infranchissables, zone d'extraction (coin bas-droit), hélicoptère à t = 60.
- **Civils** : fuient les zombies, vont vers l'extraction, cohésion + alignement avec les voisins (flocking), ramassent des vivres, posent des barricades. La moitié connaît la carte (plus court chemin), les autres vont « droit » vers le point d'extraction.
- **Zombies** : poursuivent un humain perçu (rayon limité), sinon suivent le bruit, sinon marche persistante. Règle d'écartement entre zombies. Plus lents que les civils.
- **Soldats** : tirent sur les zombies proches (le tir fait du bruit).
- **Infection** : morsure avec probabilité `p_infection`, incubation de 8 ticks, puis le civil devient zombie.
- **Communication** : indirecte, par le **bruit** (pas, tirs, événements aléatoires) qui diffuse et décroît.
- **Spores** (option, inspiration *Ophiocordyceps*) : un zombie âgé cherche un carrefour fréquenté, s'immobilise et libère une zone contaminante.

## Simplifications à assumer à l'oral

- Perception par distance de chemin (pas de ligne de vue).
- Les barricades sont franchissables par les civils, pas par les zombies (ils doivent les détruire).
- Paramètres de référence calibrés à la main pour obtenir un régime où l'issue est incertaine.
