"""
Campagne d'expériences :
  E1  courbes de référence (cinétique de l'infection, évacuation, clusters)
  E2  scénarios (taux de réussite)
  E3  ablations pour PROUVER l'émergence (encerclement, convois)
  E4  analyse de sensibilité + seuil critique (ratio zombies/civils)

Usage :  python run_experiments.py --reps 30          (complet, ~15-25 min sur 1 coeur)
         python run_experiments.py --reps 5 --quick   (test rapide)
"""
import sys
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass
import argparse
import os
import time
from dataclasses import replace
from multiprocessing import Pool

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

from model import Params, Model

BASE = Params()


def _job(args):
    name, params, rep = args
    p = replace(params, seed=1000 + rep)
    m = Model(p).run()
    s = m.summary()
    s.update(scenario=name, rep=rep)
    ts = pd.DataFrame(m.history)
    ts["scenario"], ts["rep"] = name, rep
    return s, ts


def run_batch(configs, reps, workers, label=""):
    """configs : dict nom -> Params. Renvoie (résumés, séries temporelles)."""
    jobs = [(n, p, r) for n, p in configs.items() for r in range(reps)]
    t0 = time.time()
    if workers > 1:
        with Pool(workers) as pool:
            res = pool.map(_job, jobs, chunksize=2)
    else:
        res = [_job(j) for j in jobs]
    print(f"[{label}] {len(jobs)} simulations en {time.time() - t0:.0f}s")
    return pd.DataFrame([r[0] for r in res]), pd.concat([r[1] for r in res], ignore_index=True)


def ci95(x):
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    if len(x) < 2:
        return np.nan
    return 1.96 * x.std(ddof=1) / np.sqrt(len(x))


def mean_curve(ts, col, scenario):
    d = ts[ts.scenario == scenario]
    g = d.groupby("t")[col]
    return g.mean(), g.apply(ci95)


# ---------------------------------------------------------------------------------------------
def e1_baseline(reps, workers, out):
    summ, ts = run_batch({"base": BASE}, reps, workers, "E1 base")
    summ.to_csv(f"{out}/e1_summary.csv", index=False)
    # on aligne les runs terminés tôt : on complète par la dernière valeur
    full = []
    for r, d in ts.groupby("rep"):
        d = d.set_index("t").reindex(range(BASE.max_steps + 1)).ffill()
        d["rep"] = r
        full.append(d.reset_index())
    ts = pd.concat(full, ignore_index=True)
    ts["scenario"] = "base"
    fig, ax = plt.subplots(1, 3, figsize=(15, 4))
    for col, lab, colr in [("civilians", "civils (non transformés)", "tab:blue"),
                           ("zombies", "zombies", "tab:red"),
                           ("evacuated", "évacués (cumul)", "tab:green"),
                           ("incubating", "en incubation", "tab:orange")]:
        m, c = mean_curve(ts, col, "base")
        ax[0].plot(m.index, m.values, label=lab, color=colr)
        ax[0].fill_between(m.index, m - c, m + c, alpha=0.2, color=colr)
    ax[0].axvline(BASE.heli_arrival, ls="--", c="gray")
    ax[0].text(BASE.heli_arrival + 2, ax[0].get_ylim()[1] * 0.9, "hélico", color="gray")
    ax[0].set(title="Évolution des populations (moyenne ± IC95)", xlabel="tick")
    ax[0].legend(fontsize=8)
    m, c = mean_curve(ts, "mean_cluster", "base")
    ax[1].plot(m.index, m.values, c="tab:purple")
    ax[1].fill_between(m.index, m - c, m + c, alpha=0.2, color="tab:purple")
    ax[1].set(title="Taille moyenne des groupes de civils", xlabel="tick")
    m, c = mean_curve(ts, "noise_total", "base")
    ax[2].plot(m.index, m.values, c="tab:gray")
    ax[2].set(title="Bruit total dans la ville", xlabel="tick")
    plt.tight_layout()
    plt.savefig(f"{out}/fig1_baseline.png", dpi=130)
    plt.close()
    return summ


# ---------------------------------------------------------------------------------------------
SCENARIOS = {
    "Référence (dispersés)": {},
    "Regroupés au départ": dict(start="clustered"),
    "Sans soldats": dict(n_soldiers=0),
    "Armes bruyantes": dict(gun_noise=15.0),
    "Sans barricades": dict(barricades=False),
    "Avec spores": dict(spores=True),
    "Sans informés": dict(informed_frac=0.0),
    "Tous informés": dict(informed_frac=1.0),
}


def e2_scenarios(reps, workers, out):
    cfg = {k: replace(BASE, **v) for k, v in SCENARIOS.items()}
    summ, ts = run_batch(cfg, reps, workers, "E2 scénarios")
    summ.to_csv(f"{out}/e2_scenarios.csv", index=False)
    g = summ.groupby("scenario")
    tab = pd.DataFrame({
        "évacués % (moy)": g.evac_frac.mean() * 100,
        "± IC95": g.evac_frac.apply(ci95) * 100,
        "infectés %": g.infected_frac.mean() * 100,
        "espérance de vie": g.life_expectancy.mean(),
        "pic zombies": g.zombies_peak.mean(),
        "barricades posées": g.barricades_built.mean(),
        "coups/barricade": g.barricade_delay_per_build.mean(),
        "cluster moy.": g.mean_cluster.mean(),
    }).loc[list(SCENARIOS)]
    tab.round(2).to_csv(f"{out}/e2_table.csv")
    print(tab.round(1).to_string())
    fig, ax = plt.subplots(figsize=(9, 4.5))
    y = np.arange(len(tab))[::-1]
    ax.barh(y, tab["évacués % (moy)"], xerr=tab["± IC95"], color="tab:green", alpha=0.8)
    ax.set_yticks(y)
    ax.set_yticklabels(tab.index)
    ax.set(xlabel="% de civils évacués (moyenne ± IC95)", title="Taux de réussite selon les scénarios")
    ref = summ[summ.scenario == "Référence (dispersés)"].evac_frac.values
    for i, name in enumerate(tab.index):
        if name == "Référence (dispersés)":
            continue
        v = summ[summ.scenario == name].evac_frac.values
        pval = stats.mannwhitneyu(ref, v).pvalue
        star = "***" if pval < .001 else "**" if pval < .01 else "*" if pval < .05 else "ns"
        ax.text(tab["évacués % (moy)"].iloc[i] + tab["± IC95"].iloc[i] + 1, y[i], star, va="center")
    plt.tight_layout()
    plt.savefig(f"{out}/fig2_scenarios.png", dpi=130)
    plt.close()
    return summ


# ---------------------------------------------------------------------------------------------
def e3_emergence(reps, workers, out):
    cfg = {
        "Règles complètes": BASE,
        "Sans règle d'écartement (zombies)": replace(BASE, zombie_spread=False),
        "Sans cohésion/alignement (civils)": replace(BASE, w_cohesion=0.0, w_align=0.0),
    }
    summ, _ = run_batch(cfg, reps, workers, "E3 émergence")
    summ.to_csv(f"{out}/e3_emergence.csv", index=False)
    res = {}
    fig, ax = plt.subplots(1, 3, figsize=(14, 4))
    for a, (col, title) in zip(ax, [("encirclement", "Encerclement (secteurs occupés /8)"),
                                    ("mean_cluster", "Taille moyenne des groupes"),
                                    ("polarization", "Polarisation (alignement des cap)")]):
        data = [summ[summ.scenario == k][col].dropna().values for k in cfg]
        a.boxplot(data, tick_labels=["complètes", "sans\nécartement", "sans\ncohésion"])
        a.set_title(title)
        base = data[0]
        for j, d in enumerate(data[1:], start=2):
            if len(base) > 1 and len(d) > 1:
                p = stats.mannwhitneyu(base, d).pvalue
                res[(col, list(cfg)[j - 1])] = p
    plt.tight_layout()
    plt.savefig(f"{out}/fig3_emergence.png", dpi=130)
    plt.close()
    tab = summ.groupby("scenario")[["encirclement", "mean_cluster", "polarization", "evac_frac"]].agg(["mean", "std"])
    tab.round(3).to_csv(f"{out}/e3_table.csv")
    print(tab.round(3).to_string())
    for k, v in res.items():
        print("  Mann-Whitney", k, "p = %.4g" % v)
    pd.Series({f"{a}|{b}": v for (a, b), v in res.items()}).to_csv(f"{out}/e3_pvalues.csv")
    return summ


# ---------------------------------------------------------------------------------------------
SWEEPS = {
    "n_zombies": [2, 5, 10, 15, 20, 30, 45],
    "zombie_vision": [2, 3, 5, 7, 9],
    "zombie_speed": [0.2, 0.35, 0.5, 0.75, 1.0],
    "p_infection": [0.1, 0.25, 0.35, 0.6, 1.0],
    "step_noise": [0.0, 0.25, 0.5, 1.0, 2.0],
    "gun_noise": [0.0, 3.0, 6.0, 12.0, 24.0],
    "n_civilians": [30, 50, 80, 120, 160],
}
LABELS = {
    "n_zombies": "zombies initiaux", "zombie_vision": "rayon de perception des zombies",
    "zombie_speed": "vitesse des zombies (proba de bouger)", "p_infection": "probabilité d'infection par morsure",
    "step_noise": "bruit des pas", "gun_noise": "bruit des tirs", "n_civilians": "civils (densité)",
}


def e4_sensitivity(reps, workers, out, quick=False):
    cfg, meta = {}, {}
    for par, vals in SWEEPS.items():
        for v in (vals[1:4] if quick else vals):
            name = f"{par}={v}"
            cfg[name] = replace(BASE, **{par: v})
            meta[name] = (par, v)
    summ, _ = run_batch(cfg, reps, workers, "E4 sensibilité")
    summ["param"] = summ.scenario.map(lambda s: meta[s][0])
    summ["value"] = summ.scenario.map(lambda s: meta[s][1])
    summ.to_csv(f"{out}/e4_sensitivity.csv", index=False)
    fig, axs = plt.subplots(2, 4, figsize=(17, 7))
    axs = axs.ravel()
    for a, par in zip(axs, SWEEPS):
        d = summ[summ.param == par].groupby("value").evac_frac
        m, c = d.mean() * 100, d.apply(ci95) * 100
        a.errorbar(m.index, m.values, yerr=c.values, marker="o", capsize=3, color="tab:green")
        a.set(xlabel=LABELS[par], ylabel="% évacués", ylim=(0, 100))
        a.grid(alpha=.3)
    # seuil critique : ratio zombies / civils
    d = summ[summ.param == "n_zombies"].groupby("value").evac_frac.mean() * 100
    ratio = d.index.values / BASE.n_civilians
    ax = axs[-1]
    ax.plot(ratio, d.values, "o-", color="tab:red")
    ax.axhline(50, ls="--", c="gray")
    thr = None
    for i in range(len(d) - 1):
        if d.values[i] >= 50 > d.values[i + 1]:
            x0, x1, y0, y1 = ratio[i], ratio[i + 1], d.values[i], d.values[i + 1]
            thr = x0 + (50 - y0) * (x1 - x0) / (y1 - y0)
    if thr:
        ax.axvline(thr, ls=":", c="tab:red")
        ax.text(thr, 55, f" seuil ≈ {thr:.2f}", color="tab:red")
    ax.set(xlabel="ratio zombies / civils", ylabel="% évacués", title="Seuil critique", ylim=(0, 100))
    plt.suptitle("Analyse de sensibilité (un paramètre varie à la fois, autres = référence)")
    plt.tight_layout()
    plt.savefig(f"{out}/fig4_sensitivity.png", dpi=130)
    plt.close()
    if thr:
        print(f"Seuil critique (50 % d'évacués) : ratio zombies/civils ≈ {thr:.3f}")
    # effet des paramètres : écart d'évacuation entre valeur min et max testées
    eff = {par: abs(summ[(summ.param == par) & (summ.value == min(SWEEPS[par]))].evac_frac.mean()
                    - summ[(summ.param == par) & (summ.value == max(SWEEPS[par]))].evac_frac.mean()) * 100
           for par in SWEEPS if not quick}
    if eff:
        print("Amplitude de l'effet sur % évacués (min -> max) :",
              {k: round(v, 1) for k, v in sorted(eff.items(), key=lambda kv: -kv[1])})
    return summ


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", type=int, default=30)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--workers", type=int, default=os.cpu_count() or 1)
    ap.add_argument("--out", default="results")
    ap.add_argument("--only", default="", help="ex: e1,e3")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    todo = set(a.only.split(",")) if a.only else {"e1", "e2", "e3", "e4"}
    if "e1" in todo:
        e1_baseline(a.reps, a.workers, a.out)
    if "e2" in todo:
        e2_scenarios(a.reps, a.workers, a.out)
    if "e3" in todo:
        e3_emergence(a.reps, a.workers, a.out)
    if "e4" in todo:
        e4_sensitivity(max(5, a.reps // 2), a.workers, a.out, quick=a.quick)
    print("Terminé -> dossier", a.out)
