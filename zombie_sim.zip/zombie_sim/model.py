"""
Modèle multi-agents : survie lors d'une apocalypse zombie urbaine.

Agents      : Civil (informé ou non de la carte), Zombie, Soldat
Environnement : ville en grille (rues de 2 cases, immeubles), champ de bruit qui diffuse
                et décroît, barricades, vivres, zone d'extraction (hélicoptère), spores (option)
Communication : indirecte, via le bruit (pas, tirs, événements ambiants) et la perception locale
Règles      : uniquement locales -> encerclement (zombies) et convois (civils) sont émergents
"""
from __future__ import annotations
import sys
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

import math
import random
from collections import deque
from dataclasses import dataclass

import numpy as np

import metrics

INF = 10 ** 6
EMPTY, CIV, ZOMBIE, SOLDIER = 0, 1, 2, 3


@dataclass
class Params:
    # --- environnement ---
    size: int = 43                 # côté de la grille (7k+1)
    n_supplies_items: int = 30     # vivres au sol
    heli_arrival: int = 60         # tick d'arrivée de l'hélicoptère
    max_steps: int = 300
    # --- populations ---
    n_civilians: int = 80
    n_zombies: int = 10
    n_soldiers: int = 4
    start: str = "dispersed"       # "dispersed" | "clustered"
    informed_frac: float = 0.5     # part de civils qui connaissent la carte
    # --- perception / vitesse ---
    civ_vision: int = 6
    zombie_vision: int = 5
    zombie_speed: float = 0.5      # probabilité de se déplacer à chaque tick (civil = 1)
    # --- infection ---
    p_infection: float = 0.35
    incubation: int = 8
    # --- règles civils ---
    w_goal: float = 1.0
    w_flee: float = 3.0
    w_cohesion: float = 0.6
    w_align: float = 0.3
    cohesion_radius: int = 5
    # --- règles zombies ---
    zombie_spread: bool = True     # règle d'écartement (anti-superposition)
    hearing_threshold: float = 0.15
    # --- bruit ---
    step_noise: float = 0.5        # bruit émis par un civil qui marche
    gun_noise: float = 6.0         # bruit d'un tir
    ambient_noise: float = 0.1     # nb moyen d'événements sonores aléatoires / tick
    ambient_amp: float = 5.0
    noise_decay: float = 0.85
    # --- barricades & vivres ---
    barricades: bool = True
    barricade_hp: int = 6
    supplies_initial_max: int = 2
    # --- soldats ---
    soldier_range: int = 5
    soldier_ammo: int = 30
    p_hit: float = 0.5
    # --- spores (inspiration Ophiocordyceps) ---
    spores: bool = False
    spore_age: int = 50            # âge à partir duquel un zombie cherche un carrefour fréquenté
    spore_duration: int = 30
    spore_radius: int = 2
    p_spore: float = 0.25
    # --- divers ---
    seed: int = 0


class Agent:
    __slots__ = ("uid", "kind", "pos", "informed", "supplies", "heading", "timer",
                 "age", "state", "tleft", "ammo", "alive", "fate", "t_fate", "bitten")

    def __init__(self, uid, kind, pos):
        self.uid, self.kind, self.pos = uid, kind, pos
        self.informed = False
        self.supplies = 0
        self.heading = (0, 0)
        self.timer = None      # compte à rebours d'incubation
        self.age = 0
        self.state = "walk"    # zombie : walk | seek | fruit
        self.tleft = 0
        self.ammo = 0
        self.alive = True
        self.fate = None       # civil : evacuated | infected | None
        self.t_fate = None
        self.bitten = False


def build_city(size):
    """True = case praticable. Rues de 2 cases (indices 0 et 6 mod 7), immeubles 5x5 entre."""
    r = np.arange(size)[:, None] % 7
    c = np.arange(size)[None, :] % 7
    street_r = (r == 0) | (r == 6)
    street_c = (c == 0) | (c == 6)
    return street_r | street_c


class Model:
    def __init__(self, params: Params | None = None, **kw):
        self.p = params or Params(**kw)
        p = self.p
        self.rng = random.Random(p.seed)
        self.nprng = np.random.default_rng(p.seed)
        S = self.S = p.size
        self.N = S * S
        self.passable = build_city(S)
        self.pass_flat = self.passable.ravel().tolist()
        self._build_neighbors()
        # zone d'extraction : coin bas-droit
        self.E = (S - 2, S - 2)
        self.ext = [self._i(r, c) for r in range(S) for c in range(S)
                    if self.passable[r, c] and max(abs(r - self.E[0]), abs(c - self.E[1])) <= 2]
        self.ext_set = set(self.ext)
        self.gdist = self._bfs(self.ext, INF)
        # état
        self.occ = [EMPTY] * self.N
        self.noise = np.zeros((S, S))
        self.noise_flat = [0.0] * self.N
        self.spore_map = [0] * self.N
        self.traffic = np.zeros((S, S))
        self.barr = {}                      # idx -> points de vie
        self.supply_items = set()
        self.civs, self.zombies, self.soldiers = [], [], []
        self.all_civs = []
        self.t = 0
        self.evacuated = 0
        self.stats = dict(barricades_built=0, barricade_hits=0, kills=0, spore_infections=0,
                          zombies_from_civ=0, rejected_infected=0)
        self.history = []
        self._uid = 0
        self._spawn()
        self._record()

    # ------------------------------------------------------------------ utilitaires
    def _i(self, r, c):
        return r * self.S + c

    def _build_neighbors(self):
        S = self.S
        pas = self.passable
        self.nbrs = [[] for _ in range(self.N)]
        for r in range(S):
            for c in range(S):
                if not pas[r, c]:
                    continue
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        if dr == 0 and dc == 0:
                            continue
                        rr, cc = r + dr, c + dc
                        if not (0 <= rr < S and 0 <= cc < S) or not pas[rr, cc]:
                            continue
                        if dr != 0 and dc != 0 and not (pas[r + dr, c] and pas[r, c + dc]):
                            continue  # pas de diagonale à travers un coin d'immeuble
                        self.nbrs[r * S + c].append(rr * S + cc)

    def _bfs(self, sources, max_depth):
        dist = [INF] * self.N
        dq = deque()
        for s in sources:
            if dist[s] != 0:
                dist[s] = 0
                dq.append(s)
        nb = self.nbrs
        while dq:
            u = dq.popleft()
            d = dist[u]
            if d >= max_depth:
                continue
            for v in nb[u]:
                if dist[v] == INF:
                    dist[v] = d + 1
                    dq.append(v)
        return dist

    def _new(self, kind, pos):
        self._uid += 1
        a = Agent(self._uid, kind, pos)
        self.occ[pos] = kind
        return a

    def _emit(self, pos, amp):
        r, c = divmod(pos, self.S)
        self.noise[r, c] += amp

    # ------------------------------------------------------------------ initialisation
    def _spawn(self):
        p, rng, S = self.p, self.rng, self.S
        cells = [i for i in range(self.N) if self.pass_flat[i]]
        er, ec = self.E
        cheb_E = lambda i: max(abs(i // S - er), abs(i % S - ec))

        # civils
        if p.start == "clustered":
            centre = (5, 6)
            R = 7
            while True:
                pool = [i for i in cells if max(abs(i // S - centre[0]), abs(i % S - centre[1])) <= R]
                if len(pool) >= p.n_civilians:
                    break
                R += 1
        else:
            pool = [i for i in cells if cheb_E(i) >= 20]
        for i in rng.sample(pool, p.n_civilians):
            a = self._new(CIV, i)
            a.informed = rng.random() < p.informed_frac
            a.supplies = rng.randint(0, p.supplies_initial_max)
            self.civs.append(a)
            self.all_civs.append(a)
        # zombies : loin de l'extraction et à >= 5 cases des civils
        civ_rc = [(a.pos // S, a.pos % S) for a in self.civs]
        pool = [i for i in cells if cheb_E(i) >= 10 and self.occ[i] == EMPTY]
        rng.shuffle(pool)
        for i in pool:
            if len(self.zombies) >= p.n_zombies:
                break
            r, c = divmod(i, S)
            if all(max(abs(r - cr), abs(c - cc)) >= 5 for cr, cc in civ_rc) and self.occ[i] == EMPTY:
                z = self._new(ZOMBIE, i)
                z.heading = rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
                self.zombies.append(z)
        # soldats autour de l'extraction
        pool = [i for i in cells if 3 <= cheb_E(i) <= 6 and self.occ[i] == EMPTY]
        for i in rng.sample(pool, min(p.n_soldiers, len(pool))):
            s = self._new(SOLDIER, i)
            s.ammo = p.soldier_ammo
            self.soldiers.append(s)
        # vivres
        free = [i for i in cells if self.occ[i] == EMPTY and i not in self.ext_set]
        self.supply_items = set(rng.sample(free, min(p.n_supplies_items, len(free))))

    # ------------------------------------------------------------------ dynamique
    def _update_noise(self):
        p = self.p
        n = self.noise
        pad = np.pad(n, 1)
        nb = (pad[:-2, 1:-1] + pad[2:, 1:-1] + pad[1:-1, :-2] + pad[1:-1, 2:]) / 4.0
        self.noise = p.noise_decay * (0.5 * n + 0.5 * nb) * self.passable
        for _ in range(self.nprng.poisson(p.ambient_noise)):
            i = self.rng.choice(self._cells_cache())
            self._emit(i, p.ambient_amp)
        self.noise_flat = self.noise.ravel().tolist()

    def _cells_cache(self):
        if not hasattr(self, "_cells"):
            self._cells = [i for i in range(self.N) if self.pass_flat[i]]
        return self._cells

    def step(self):
        if self.done:
            return
        p, rng, S = self.p, self.rng, self.S
        occ, nbrs = self.occ, self.nbrs
        self._update_noise()
        heli = self.t >= p.heli_arrival
        self.traffic *= 0.995
        # décroissance des spores
        self.spore_map = [max(0, v - 1) for v in self.spore_map]

        # champs de perception
        self.zdist = self._bfs([z.pos for z in self.zombies], p.civ_vision)
        self.hdist = self._bfs([a.pos for a in self.civs + self.soldiers], p.zombie_vision)

        self._civilians_act(heli)
        self._soldiers_act()
        self._zombies_act()
        self._incubation()
        self._cleanup()
        self.t += 1
        self._record()

    # ---------------------------------------------------------------- civils
    def _civilians_act(self, heli):
        p, rng, S = self.p, self.rng, self.S
        occ, nbrs, zd, gd = self.occ, self.nbrs, self.zdist, self.gdist
        sp = self.spore_map
        er, ec = self.E
        civs = [a for a in self.civs if a.alive]
        n = len(civs)
        if n == 0:
            return
        P = np.array([(a.pos // S, a.pos % S) for a in civs], dtype=float)
        H = np.array(self._unit([a.heading for a in civs]))
        D = np.abs(P[:, None, :] - P[None, :, :]).max(axis=2)
        M = (D <= p.cohesion_radius) & (D > 0)
        cnt = M.sum(1)
        Mf = M.astype(float)
        with np.errstate(invalid="ignore", divide="ignore"):
            cen = np.where(cnt[:, None] > 0, (Mf @ P) / np.maximum(cnt, 1)[:, None], P)
            mh = np.where(cnt[:, None] > 0, (Mf @ H) / np.maximum(cnt, 1)[:, None], 0.0)
        order = list(range(n))
        rng.shuffle(order)
        for k in order:
            a = civs[k]
            pos = a.pos
            r, c = divmod(pos, S)
            zhere = zd[pos]
            panic = zhere <= 2
            wf = p.w_flee * (2.0 if panic else 1.0)
            wc = 0.0 if panic else p.w_cohesion
            best, best_s = pos, -1e18
            for v in [pos] + [v for v in nbrs[pos] if occ[v] == EMPTY]:
                vr, vc = divmod(v, S)
                s = -p.w_goal * (gd[v] if a.informed else math.hypot(vr - er, vc - ec))
                z = zd[v]
                if z <= p.civ_vision:
                    s -= wf * (p.civ_vision + 1 - z)
                if sp[v] > 0:
                    s -= wf * 3.0
                if cnt[k] > 0:
                    if wc > 0:
                        s -= wc * math.hypot(vr - cen[k, 0], vc - cen[k, 1])
                    if p.w_align > 0 and v != pos:
                        s += p.w_align * ((vr - r) * mh[k, 0] + (vc - c) * mh[k, 1])
                if v == pos and pos not in self.ext_set:
                    s -= 0.3
                s += rng.random() * 0.3
                if s > best_s:
                    best, best_s = v, s
            if best != pos:
                occ[pos] = EMPTY
                occ[best] = CIV
                br, bc = divmod(best, S)
                a.heading = (br - r, bc - c)
                a.pos = best
                self.traffic[br, bc] += 1.0
                if p.step_noise > 0:
                    self._emit(best, p.step_noise)
                # barricade derrière soi quand un zombie approche
                if (p.barricades and a.supplies > 0 and zhere <= 3 and pos not in self.ext_set
                        and pos not in self.barr and rng.random() < 0.5):
                    self.barr[pos] = p.barricade_hp
                    a.supplies -= 1
                    self.stats["barricades_built"] += 1
            else:
                a.heading = (0, 0)
            if a.pos in self.supply_items:
                self.supply_items.discard(a.pos)
                a.supplies += 1
            # spores
            if p.spores and sp[a.pos] > 0 and a.timer is None and rng.random() < p.p_spore:
                a.timer = p.incubation
                a.bitten = True
                a.t_fate = a.t_fate if a.fate else self.t
                self.stats["spore_infections"] += 1
            # évacuation
            if heli and a.pos in self.ext_set:
                if a.timer is None:
                    a.alive = False
                    a.fate, a.t_fate = "evacuated", self.t
                    occ[a.pos] = EMPTY
                    self.evacuated += 1
                else:
                    self.stats["rejected_infected"] += 1

    @staticmethod
    def _unit(heads):
        out = []
        for dr, dc in heads:
            nrm = math.hypot(dr, dc)
            out.append((dr / nrm, dc / nrm) if nrm > 0 else (0.0, 0.0))
        return out if out else [(0.0, 0.0)]

    # ---------------------------------------------------------------- soldats
    def _soldiers_act(self):
        p, S, rng = self.p, self.S, self.rng
        for s in self.soldiers:
            if not s.alive or s.ammo <= 0 or not self.zombies:
                continue
            sr, sc = divmod(s.pos, S)
            best, bd = None, 1e9
            for z in self.zombies:
                if not z.alive:
                    continue
                d = max(abs(z.pos // S - sr), abs(z.pos % S - sc))
                if d <= p.soldier_range and d < bd:
                    best, bd = z, d
            if best is not None:
                s.ammo -= 1
                self._emit(s.pos, p.gun_noise)
                if rng.random() < p.p_hit:
                    best.alive = False
                    self.occ[best.pos] = EMPTY
                    self.stats["kills"] += 1

    # ---------------------------------------------------------------- zombies
    def _zombies_act(self):
        p, S, rng = self.p, self.S, self.rng
        occ, nbrs, hd, nz = self.occ, self.nbrs, self.hdist, self.noise_flat
        zs = [z for z in self.zombies if z.alive]
        rng.shuffle(zs)
        for z in zs:
            if not z.alive:
                continue
            z.age += 1
            # spores : fin de vie -> recherche d'un carrefour fréquenté puis fructification
            if p.spores:
                if z.state == "walk" and z.age >= p.spore_age:
                    z.state = "seek"
                if z.state == "seek":
                    tr = self.traffic
                    r, c = divmod(z.pos, S)
                    cur = tr[r, c]
                    cand = [(tr[v // S, v % S], v) for v in nbrs[z.pos] if occ[v] == EMPTY]
                    cand = [x for x in cand if x[0] > cur + 1e-9]
                    if cand and rng.random() < 0.8:
                        _, v = max(cand)
                        occ[z.pos] = EMPTY
                        occ[v] = ZOMBIE
                        z.pos = v
                        continue
                    z.state, z.tleft = "fruit", p.spore_duration
                if z.state == "fruit":
                    self._release_spores(z)
                    z.tleft -= 1
                    if z.tleft <= 0:
                        z.alive = False
                        occ[z.pos] = EMPTY
                    continue
            pos = z.pos
            # attaque : humain adjacent
            targets = [v for v in nbrs[pos] if occ[v] in (CIV, SOLDIER)]
            if targets:
                v = rng.choice(targets)
                tgt = next((a for a in (self.civs if occ[v] == CIV else self.soldiers)
                            if a.pos == v and a.alive), None)
                if tgt is not None and tgt.timer is None:
                    pinf = p.p_infection if tgt.kind == CIV else p.p_infection * 0.5
                    if rng.random() < pinf:
                        tgt.timer = p.incubation
                        tgt.bitten = True
                        if tgt.kind == CIV:
                            tgt.fate, tgt.t_fate = "infected", self.t
                continue
            if rng.random() > p.zombie_speed:
                continue
            cands = [v for v in nbrs[pos] if occ[v] == EMPTY]
            if not cands:
                continue
            choice = None
            if hd[pos] < INF:  # un humain est perçu : poursuite
                best_c = 1e18
                for v in cands:
                    cost = hd[v] + (1.5 if v in self.barr else 0.0) + rng.random() * 0.1
                    if p.zombie_spread:  # règle d'écartement : éviter les cases voisines d'autres zombies
                        cost += 0.6 * sum(1 for w in nbrs[v] if occ[w] == ZOMBIE)
                    if cost < best_c:
                        choice, best_c = v, cost
                if hd[choice] > hd[pos] + 0.5 and choice not in self.barr:
                    choice = pos if rng.random() < 0.5 else choice
            else:              # sinon : bruit, sinon marche persistante
                bn = max(cands, key=lambda v: nz[v])
                if nz[bn] > p.hearing_threshold and nz[bn] > nz[pos]:
                    choice = bn
                else:
                    hr, hc = z.heading
                    r, c = divmod(pos, S)
                    ahead = (r + hr) * S + (c + hc) if 0 <= r + hr < S and 0 <= c + hc < S else -1
                    if ahead in cands and rng.random() < 0.7:
                        choice = ahead
                    else:
                        choice = rng.choice(cands)
            if choice is None or choice == pos:
                continue
            if choice in self.barr:  # le zombie s'attaque à la barricade
                self.barr[choice] -= 1
                self.stats["barricade_hits"] += 1
                if self.barr[choice] <= 0:
                    del self.barr[choice]
                continue
            r, c = divmod(pos, S)
            nr, nc = divmod(choice, S)
            z.heading = (nr - r, nc - c)
            occ[pos] = EMPTY
            occ[choice] = ZOMBIE
            z.pos = choice

    def _release_spores(self, z):
        S, R = self.S, self.p.spore_radius
        r, c = divmod(z.pos, S)
        for rr in range(max(0, r - R), min(S, r + R + 1)):
            for cc in range(max(0, c - R), min(S, c + R + 1)):
                if self.pass_flat[rr * S + cc]:
                    self.spore_map[rr * S + cc] = 2

    # ---------------------------------------------------------------- incubation
    def _incubation(self):
        new = []
        for a in self.civs + self.soldiers:
            if a.alive and a.timer is not None:
                a.timer -= 1
                if a.timer <= 0:
                    a.alive = False
                    z = Agent(self._uid + 1, ZOMBIE, a.pos)
                    self._uid += 1
                    z.heading = (0, 1)
                    self.occ[a.pos] = ZOMBIE
                    new.append(z)
                    if a.kind == CIV:
                        self.stats["zombies_from_civ"] += 1
        self.zombies.extend(new)

    def _cleanup(self):
        self.civs = [a for a in self.civs if a.alive]
        self.soldiers = [a for a in self.soldiers if a.alive]
        self.zombies = [z for z in self.zombies if z.alive]

    @property
    def done(self):
        no_civ_left = not any(a.alive and a.timer is None for a in self.civs)
        return self.t >= self.p.max_steps or no_civ_left

    # ---------------------------------------------------------------- mesures
    def _record(self):
        S = self.S
        civ_pos = [(a.pos // S, a.pos % S) for a in self.civs]
        zom_pos = [(z.pos // S, z.pos % S) for z in self.zombies]
        sizes = metrics.cluster_sizes(civ_pos, S)
        pol = np.nan
        if len(self.civs) >= 3:
            P = np.array(civ_pos, dtype=float)
            D = np.abs(P[:, None, :] - P[None, :, :]).max(axis=2)
            H = np.array(self._unit([a.heading for a in self.civs]))
            pol = metrics.polarization(H, (D <= 3) & (D > 0))
        enc, enc_n = metrics.encirclement(civ_pos, zom_pos)
        self.history.append(dict(
            t=self.t,
            civilians=len(self.civs),
            incubating=sum(1 for a in self.civs if a.timer is not None),
            zombies=len(self.zombies),
            soldiers=len(self.soldiers),
            evacuated=self.evacuated,
            mean_cluster=float(np.mean(sizes)) if sizes else np.nan,
            max_cluster=max(sizes) if sizes else 0,
            polarization=pol,
            encirclement=enc,
            encl_n=enc_n,
            noise_total=float(self.noise.sum()),
        ))

    def run(self):
        while not self.done:
            self.step()
        return self

    def summary(self):
        p = self.p
        n = p.n_civilians
        h = self.history
        t_end = self.t
        # espérance de vie (censurée à t_end) : tick de morsure/spores ou d'évacuation
        life = [(a.t_fate if a.t_fate is not None else t_end) for a in self.all_civs]
        z = np.array([row["zombies"] for row in h[:61]], dtype=float)
        tt = np.arange(len(z))
        growth = float(np.polyfit(tt, np.log(np.maximum(z, 1)), 1)[0]) if len(z) > 5 else np.nan
        mean = lambda k: float(np.nanmean([row[k] for row in h])) if not all(
            (isinstance(row[k], float) and math.isnan(row[k])) for row in h) else np.nan
        bit = sum(1 for a in self.all_civs if a.bitten)
        evac_times = [a.t_fate for a in self.all_civs if a.fate == "evacuated"]
        return dict(
            evac_frac=self.evacuated / n,
            infected_frac=bit / n,
            lost_other_frac=max(0.0, 1 - self.evacuated / n - bit / n),
            life_expectancy=float(np.mean(life)),
            zombies_peak=max(r["zombies"] for r in h),
            zombies_final=h[-1]["zombies"],
            zombie_growth=growth,
            mean_cluster=mean("mean_cluster"),
            max_cluster=max(r["max_cluster"] for r in h),
            polarization=mean("polarization"),
            encirclement=mean("encirclement"),
            t_end=t_end,
            t_last_evac=max(evac_times) if evac_times else np.nan,
            **self.stats,
            barricade_delay_per_build=(self.stats["barricade_hits"] / self.stats["barricades_built"]
                                       if self.stats["barricades_built"] else np.nan),
        )


def run_one(params: Params):
    m = Model(params).run()
    import pandas as pd
    return m.summary(), pd.DataFrame(m.history)


if __name__ == "__main__":
    import time
    t0 = time.time()
    s, ts = run_one(Params(seed=1))
    print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in s.items()})
    print("durée : %.2fs" % (time.time() - t0))
