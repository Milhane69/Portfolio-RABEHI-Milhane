"""Visualisation : GIF d'une simulation, ou fenêtre live (--live)."""
import sys
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass
import argparse
import numpy as np
import matplotlib
from matplotlib.colors import ListedColormap
from model import Model, Params, EMPTY, CIV, ZOMBIE, SOLDIER


def frame_image(m):
    S = m.S
    img = np.zeros((S, S, 3))
    img[~m.passable] = (0.25, 0.25, 0.28)          # immeubles
    img[m.passable] = (0.85, 0.85, 0.82)           # rues
    noise = np.clip(m.noise / 3.0, 0, 1)[..., None]
    img = img * (1 - 0.5 * noise) + np.array([1.0, 0.8, 0.2]) * 0.5 * noise   # bruit (jaune)
    for i in m.ext:
        img[i // S, i % S] = (0.55, 0.9, 0.55)      # zone d'extraction
    for i, v in enumerate(m.spore_map):
        if v > 0:
            img[i // S, i % S] = (0.7, 0.5, 0.8)    # spores
    for i in m.barr:
        img[i // S, i % S] = (0.55, 0.35, 0.15)     # barricades
    for a in m.civs:
        img[a.pos // S, a.pos % S] = (0.1, 0.3, 0.9) if a.informed else (0.4, 0.6, 1.0)
    for a in m.soldiers:
        img[a.pos // S, a.pos % S] = (0.0, 0.4, 0.0)
    for z in m.zombies:
        img[z.pos // S, z.pos % S] = (0.85, 0.1, 0.1)
    return img


def title(m):
    return (f"t={m.t}  civils={len(m.civs)}  zombies={len(m.zombies)}  "
            f"évacués={m.evacuated}" + ("  [hélico là]" if m.t >= m.p.heli_arrival else ""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=3)
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--out", default="simulation.gif")
    ap.add_argument("--every", type=int, default=2)
    ap.add_argument("--spores", action="store_true")
    ap.add_argument("--clustered", action="store_true")
    a = ap.parse_args()
    if not a.live:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation, PillowWriter
    p = Params(seed=a.seed, spores=a.spores, start="clustered" if a.clustered else "dispersed")
    m = Model(p)
    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    im = ax.imshow(frame_image(m), interpolation="nearest")
    ax.set_xticks([]); ax.set_yticks([])
    ttl = ax.set_title(title(m), fontsize=10)

    def update(_):
        for _ in range(a.every):
            m.step()
        im.set_data(frame_image(m))
        ttl.set_text(title(m))
        return im, ttl

    if a.live:
        ani = FuncAnimation(fig, update, interval=80, cache_frame_data=False)
        plt.show()
    else:
        n_frames = p.max_steps // a.every
        ani = FuncAnimation(fig, update, frames=n_frames, cache_frame_data=False)
        ani.save(a.out, writer=PillowWriter(fps=12))
        print("GIF écrit :", a.out, "| évacués :", m.evacuated, "/", p.n_civilians)


if __name__ == "__main__":
    main()
